package com.example.uma.final_project;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.widget.ImageView;
import android.widget.TextView;
//import sun.misc.BASE64Decoder;

public class SecondActivity extends AppCompatActivity {

    TextView t1,t2,t3,t4;
    ImageView t5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        Intent intent= getIntent();
        String id= intent.getStringExtra("id");
        String description = intent.getStringExtra("description");
        String offers = intent.getStringExtra("offers");
        String expirationDate1 = intent.getStringExtra("expdate");
        String image=intent.getStringExtra("image");

        //BASE64Decoder decoder= new BASE64Decoder();
        byte[] imageBytes = Base64.decode(image, Base64.DEFAULT);
        Bitmap decodedImage = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.length);

        System.out.println("From secnd activity"+ id+ " "+ description+" "+ offers+" "+ expirationDate1);

        t1=(TextView)findViewById(R.id.textView2);
        t2=(TextView)findViewById(R.id.textView3);
        t3=(TextView)findViewById(R.id.textView4);
        t4=(TextView)findViewById(R.id.textView5);
        t5=(ImageView) findViewById(R.id.imageView3);

        t1.setText(id);
        t2.setText(description);
        t3.setText(offers);
        t4.setText(expirationDate1);
        t5.setImageBitmap(decodedImage);
    }
}


